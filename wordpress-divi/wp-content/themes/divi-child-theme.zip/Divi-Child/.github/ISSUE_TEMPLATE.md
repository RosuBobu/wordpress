Make sure these boxes are checked before submitting your issue.

- [ ] You are using this for WordPress.
- [ ] You have Divi installed.
- [ ] You have lint your code to ensure the problem isn't caused by your code.
- [ ] You have already searched the GitHub issues and it has not been reported before.

-

