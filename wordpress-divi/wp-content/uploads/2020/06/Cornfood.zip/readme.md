# Cornfood - intégration web #bootstrap

Intégrer la maquette de l'interface Cornfood : <a href="https://www.behance.net/gallery/76857623/Maquette-Cornfood" target="_blank">voir la maquette</a>

Toutes les ressources images nécessaires se trouvent dans le dossier `img` et la font Rockweel dans `css/font`.

Ce corrigé utilise la version 4 de Bootstrap et un maximum de ses classes pour réduire le code CSS et intégrer plus facilement le responsive.

<a href="https://audelweiss.github.io/Exercices-developpement/Cornfood/" target="_blank">Voir le site intégré</a>
